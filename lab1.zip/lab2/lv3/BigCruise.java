class BigCruise extends Cruise {
    public BigCruise(String code, int time) {
        super(code, time);
    }
    
    public String getCode() {
        return this.code;
    }
    //to get time in minutes
    public int getTime() {
        return this.minute;
    }

    public int workTime() { //how long the loader for the cruise takes to load
        return 60;
    }

    @Override
    public String toString() {
        return code + "@" + String.format("%04d", time);
    }
}
