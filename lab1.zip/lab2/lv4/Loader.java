import java.util.ArrayList;
import java.util.List;

class Loader{

    ArrayList<Cruise> cruise = new ArrayList<Cruise>();    
    int numLoader;
    int prevCruiseTime = 0;

    public int nextLoadTime(Cruise c) {
        prevCruiseTime = c.getTime() + c.workTime();
        return prevCruiseTime;
    }

    public boolean checkAvail(Cruise c) {
        return (prevCruiseTime <= c.getTime());

    }

    public void getServe(Cruise c) { //arraylist of cruises the loader serve
        cruise.add(c);
        nextLoadTime(c);
    }

    public Loader(int numLoader) {
        this.numLoader = numLoader;
    }

    public void PrintCruise() {
        System.out.println("Loader " + (numLoader + 1) + " serves:");
        for (int i = 0; i < cruise.size(); i++) {
            System.out.println("    " + cruise.get(i).toString());
        }
    }
}
