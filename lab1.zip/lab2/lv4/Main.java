import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Main{

    public static ArrayList<Cruise> ReadInput() {
        Scanner sc = new Scanner(System.in);
        int numCruise = sc.nextInt();
        ArrayList<Cruise> cruise = new ArrayList<Cruise>();
        for (int i = 0; i < numCruise; i++) {
            String temp = sc.next();
            if (temp.charAt(0) == 'B') {
                cruise.add(new BigCruise(temp, sc.nextInt()));    
            } else {
                cruise.add(new Cruise(temp, sc.nextInt()));
            }
        }
        return cruise;
    } 

    static ArrayList<Loader> loader = new ArrayList<Loader>();
    public static void AllocLoader(ArrayList<Cruise> cruise) {
        int numLoader = 0;
        for (int i = 0; i < cruise.size(); i++) {//loop thru Cruise arraylist
            int counter;
            if (cruise.get(i).getCode().charAt(0) == 'B') {
                counter = 2;
            } else {
                counter = 1;    
            }

            for (int k = 0; k < counter; k++) {
                if (numLoader == 0) { //loaderlist initially empty, so add loader
                    loader.add(new Loader(numLoader)); //create new loader object
                    loader.get(i).getServe(cruise.get(i));
                    numLoader++;
                } else { 
                    int temp = numLoader;
                    for (int j = 0; j < temp; j++) { //check availability of each loader 
                        if (loader.get(j).checkAvail(cruise.get(i))) {
                            loader.get(j).getServe(cruise.get(i));
                            break;
                        }
                        if (j == numLoader - 1) {
                            //make a new loader;
                            //then put the loader in to the arraylist of loader
                            if ((numLoader + 1) % 3 == 0) {
                                loader.add(new RecycledLoader(numLoader));
                            } else {                           
                                loader.add(new Loader(numLoader));
                            }

                            loader.get(numLoader).getServe(cruise.get(i));
                            numLoader++;
                        }
                    }
                }
            }
        }
    }

    public static void Print(ArrayList<Loader> l) {
        for (int i = 0; i < l.size(); i++) {
           if (l.get(i) instanceof RecycledLoader) { 
                // skip the recycled loader first. print at the end            
            } else { 
                l.get(i).PrintCruise();       
           }
        }

        for (int i = 0; i < l.size(); i++) {
            if (l.get(i) instanceof RecycledLoader) {
                l.get(i).PrintCruise();
            } else { }
        }
    }

    public static void main(String[] args) {
        ArrayList<Cruise> input_arr = ReadInput();
        AllocLoader(input_arr);
        Print(loader);
    }
}
