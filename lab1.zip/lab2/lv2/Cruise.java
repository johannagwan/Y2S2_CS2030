class Cruise{
    protected String code;
    protected int time;
    protected int minute;
    
    public Cruise(String code, int time) {
        this.code = code;
        this.time = time;
        this.minute = time / 100 * 60 + time%100;
    }
    
    public String getCode() {
        return this.code;
    }
    //to get time in minutes
    public int getTime() {
        return this.minute;
    }

    public int workTime() { //how long the loader for the cruise takes to load
        return 30;
    }

    @Override
    public String toString() {
        return code + "@" + String.format("%04d", time);
    }
}
