import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Main{

    public static ArrayList<Cruise> ReadInput() {
        Scanner sc = new Scanner(System.in);
        int numCruise = sc.nextInt();
        ArrayList<Cruise> cruise = new ArrayList<Cruise>();
        for (int i = 0; i < numCruise; i++) {    
            cruise.add(new Cruise(sc.next(), sc.nextInt()));
        }
        return cruise;
    } 

    static ArrayList<Loader> loader = new ArrayList<Loader>();
    public static void AllocLoader(ArrayList<Cruise> cruise) {
        int numLoader = 0;
        for (int i = 0; i < cruise.size(); i++) {
            if (numLoader == 0) { //loaderlist initially empty, so add loader
                loader.add(new Loader(numLoader)); //create new loader object loader.get(i).getServe(cruise.get(i));
                loader.get(i).getServe(cruise.get(i));
                numLoader++;
            } else { 
                int temp = numLoader;
                for (int j = 0; j < temp; j++) { //check availability of each loader 
                    if (loader.get(j).checkAvail(cruise.get(i))) {
                        loader.get(j).getServe(cruise.get(i));
                        break;
                    }
                    if (j == numLoader - 1) {
                        //make a new loader;
                        //then put the loader in to the arraylist of loader
                        loader.add(new Loader(numLoader));
                        loader.get(numLoader).getServe(cruise.get(i));
                        numLoader++;
                    }
                }
            }
         }
        

    }

    public static void Print(ArrayList<Loader> l) {
        for (int i = 0; i < l.size(); i++) {
            l.get(i).PrintCruise(); 
        }
    }

    public static void main(String[] args) {
        ArrayList<Cruise> input_arr = ReadInput();
        AllocLoader(input_arr);
        Print(loader);
    }
}
