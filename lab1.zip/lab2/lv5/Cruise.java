class Cruise{
    protected String code;
    protected int time;
    protected int minute;
    protected static int numCruise = 0;
    
    public Cruise(String code, int time) {
        this.code = code;
        this.time = time;
        this.minute = time / 100 * 60 + time%100;
        numCruise++;
    }
    
    public String getCode() {
        return this.code;
    }

    public int getTime() {
        return this.minute;
    }

    public int workTime() {
        return 30;
    }

    public static int getNumCruise() {
        return numCruise;
    }

    @Override
    public String toString() {
        return code + "@" + String.format("%04d", time);
    }
}
