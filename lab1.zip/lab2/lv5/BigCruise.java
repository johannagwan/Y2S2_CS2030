class BigCruise extends Cruise {
    public static int numBigCruise = 0;
    
    public BigCruise(String code, int time) {
        super(code, time);
        numBigCruise++;
        super.numCruise--;
    }
    
    public int workTime() { //how long the loader for the cruise takes to load
        return 60;
    }

    public static int getNumCruise() {
        return numBigCruise;
    }

    @Override
    public String toString() {
        return code + "@" + String.format("%04d", time);
    }
}
