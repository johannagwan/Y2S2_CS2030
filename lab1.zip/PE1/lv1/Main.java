import java.util.Scanner;

class Main{
    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in);

        while (sc.hasNext()) {
            Employee employee = new Employee(sc.next(), sc.next(), sc.nextDouble());
            employee.setSalaryIncrease(sc.nextDouble());
            System.out.println(employee);
        }
    }
}
