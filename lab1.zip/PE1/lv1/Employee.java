class Employee{
    String firstName;
    String lastName;
    double initSalary;
    double raiseRate;
    double newSalary;
    double annualRaise;

    public Employee(String firstName, String lastName, double salary) {
        this.firstName = firstName;
        this.lastName = lastName;
        initSalary = salary;
    }

    public void setSalaryIncrease(double raiseRate) {
        newSalary = initSalary * raiseRate; 
    }

    public double getAnnualRaise() {
        annualRaise = (newSalary - initSalary) / initSalary;
        return annualRaise;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + ": salary is " + String.format("%.0f", (initSalary/1000)) + "K, annual raise is " + String.format("%.0f", (this.getAnnualRaise() * 100)) + "%";
    }
}
