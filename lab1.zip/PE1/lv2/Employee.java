class Employee{
    String firstName;
    String lastName;
    double initSalary;
    double raiseRate;
    double newSalary;
    double annualRaise;
    SalaryAdjust adjustment;

    public Employee(String firstName, String lastName, double salary, SalaryAdjust adjustment) {
        this.firstName = firstName;
        this.lastName = lastName;
        initSalary = salary;
        this.adjustment = adjustment;
    }

    public void setSalaryIncrease(double raiseRate) {
        newSalary = initSalary * raiseRate; 
    }

    public double getAnnualRaise() {
        annualRaise = ((newSalary - initSalary) / initSalary) * 100;
        if (annualRaise > 10 || annualRaise < 0) {
            annualRaise = adjustment.adjust(annualRaise);
        }
        return annualRaise;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + ": salary is " + String.format("%.0f", (initSalary/1000)) + "K, annual raise is " + String.format("%.0f", (this.getAnnualRaise())) + "%";
    }
}
