abstract class SalaryAdjust{
    double raise;
    
    public SalaryAdjust() {
    
    }

    public abstract double adjust(double raise);
}
