import java.lang.Math;

class SavingsAccount implements Comparable<SavingsAccount> {
    Employee employee;
    Bank bank;
    int months;
    double salaryRaise;
    double totalSalary;

    public SavingsAccount(Employee employee, Bank bank) {
        this.employee = employee;
        this.bank = bank;
    }

    public Employee getEmployee() {
        return employee;
    }

    public double compute(int months) {
        double monthlyRate = bank.getBankRate() / 12; 
        double initSalary = employee.getSalary(); 
        double r = 1 + monthlyRate;
        int numYear = months / 12;
        double annualRaiseRate = (employee.getAnnualRaise() + 100) / 100;
        totalSalary = 0;

        int monthsLeft = months;
        for (int j = 0; j < numYear + 1; j++) {
            if (monthsLeft > 12) {
                for (int i = 0; i < 12; i++) {
                    totalSalary += initSalary;
                    totalSalary *= r;
                }
                initSalary *= annualRaiseRate;
                monthsLeft -= 12;
            } else {
                for (int i = 0; i < monthsLeft; i++) {
                    totalSalary += initSalary;
                    totalSalary *= r;
                }
                break;
            }
        }
        return totalSalary;
    }

    public int compareTo(SavingsAccount account) {
        if (this.totalSalary < account.totalSalary) {
            return -1;
        } else if (this.totalSalary > account.totalSalary) {
            return 1;
        } else {
            return 0;
        }
    }
}
