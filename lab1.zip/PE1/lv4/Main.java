import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PriorityQueue<SavingsAccount> pq = new PriorityQueue<SavingsAccount>();

        SalaryAdjust adjustment = new Type1Adjustment(); //included

        /* read number of months */
        int months = sc.nextInt();
   
        /* included to read the list of banks */
        Bank.BANKS = new Bank[4]; //array of banks
        for (int i = 0; i < Bank.BANKS.length; i++) {
            Bank.BANKS[i] = new Bank(sc.next(), sc.nextDouble());
        }

        while (sc.hasNext()) {
            Employee employee = new Employee(sc.next(), sc.next(), 
                    sc.nextDouble(), adjustment); //modified
            employee.setSalaryIncrease(sc.nextDouble());
            SavingsAccount account = new SavingsAccount(employee,    // added
                    Bank.getBankByName(sc.next()));
            account.compute(months);
            pq.add(account);
        }
        
        int len = pq.size();
        for (int i = 0; i < len; i++) {
            SavingsAccount acc = pq.poll();
            System.out.println(acc.getEmployee() + " " + "has balance of " + String.format("%.2f", acc.compute(months))); 
            
        }
    }
}
