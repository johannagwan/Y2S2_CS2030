import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        SalaryAdjust adjustment = new Type1Adjustment(); //included

        /* read number of months */
        int months = sc.nextInt();
   
        /* included to read the list of banks */
        Bank.BANKS = new Bank[4]; //array of banks
        for (int i = 0; i < Bank.BANKS.length; i++) {
            Bank.BANKS[i] = new Bank(sc.next(), sc.nextDouble());
        }

        while (sc.hasNext()) {
            Employee employee = new Employee(sc.next(), sc.next(), 
                    sc.nextDouble(), adjustment); //modified
            employee.setSalaryIncrease(sc.nextDouble());
            SavingsAccount account = new SavingsAccount(employee,    // added
                    Bank.getBankByName(sc.next()));
            System.out.println(employee + " " + "has balance of " +  // modified 
                    String.format("%.2f", account.compute(months))); 
        }
    }
}
