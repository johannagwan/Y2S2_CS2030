class Bank{
    String bankName;
    double bankRate;
    static Bank[] BANKS; 
    static Bank desiredBank;

    public Bank(String bankName, double bankRate) {
        this.bankName = bankName;
        this.bankRate = bankRate;
    }

    public static Bank getBankByName(String bankName) { 
        for (int i = 0; i < BANKS.length; i++) {
            String inputBankName = BANKS[i].getBankName();
            if (inputBankName.equals(bankName)) {
                desiredBank = BANKS[i];
            }
        } 
        return desiredBank;
    }

    public String getBankName() {
        return bankName;
    }

    public double getBankRate() {
        return bankRate;
    }
}
