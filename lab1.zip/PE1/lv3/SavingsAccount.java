import java.lang.Math;

class SavingsAccount{
    Employee employee;
    Bank bank;
    int months;
    double salaryRaise;

    public SavingsAccount(Employee employee, Bank bank) {
        this.employee = employee;
        this.bank = bank;
    }

    public double compute(int months) {
        double monthlyRate = bank.getBankRate() / 12; 
        double initSalary = employee.getSalary(); 
        double r = 1 + monthlyRate;
        double a = initSalary * r;
        int numYear = months / 12;
        double annualRaiseRate = (employee.getAnnualRaise() + 100) / 100;

		double totalSalary = 0;
		int monthsLeft = months;
		for (int j = 0; j < numYear + 1; j++) {
			if (monthsLeft > 12) {
				for (int i = 0; i < 12; i++) {
					totalSalary += initSalary;
					totalSalary *= r;
				}
				initSalary *= annualRaiseRate;
				monthsLeft -= 12;
			} else {
				for (int i = 0; i < monthsLeft; i++) {
					totalSalary += initSalary;
					totalSalary *= r;
				}
				break;
			}
		}
		return totalSalary;
    }
}
