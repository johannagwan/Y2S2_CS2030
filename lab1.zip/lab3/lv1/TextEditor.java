import java.util.*;

class TextEditor{
    List<TextFormatter> formatter;

    public TextEditor(List<TextFormatter> formatter) {
        this.formatter = formatter;
    }

    //add a string into Text Editor
    ArrayList<String> arr_str = new ArrayList<String>();    
    public void addString(String s) {
        arr_str.add(s);
    }

    // to print all formatted strings
    public void printAll() {
        for(TextFormatter f : formatter) { //loop through each formatter
            System.out.println(f.format());

        }
    }
}
