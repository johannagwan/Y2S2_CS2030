import java.util.*;
import java.lang.StringBuilder;

class SnakeCaseFormatter implements TextFormatter {

    String str;
    // create a clone of the TextFormatter with another String
    public TextFormatter clone(String s){ //s is a whole line of words
        return new SnakeCaseFormatter(s);
    }

    public SnakeCaseFormatter(String s) {
        this.str = s;
    }

    // return a formatted String
    public String format(){
        String temp = str.toLowerCase();
        StringBuilder sb = new StringBuilder(temp);
        for (int i = 0; i < sb.length(); i++) {
            if (temp.charAt(i) == ' ') {
                sb.replace(i, i+1, "_");
            }
        }
        return sb.toString();
    }
}
