import java.util.*;

class Main {
    public static void main(String[] args) {
        ArrayList<TextFormatter> f = new ArrayList<TextFormatter>(); //list of formatters
        Scanner sc = new Scanner(System.in);
        //for loop
        while (sc.hasNextLine()) {
            //read 1 line
            String nl = sc.nextLine();
            f.add(new SnakeCaseFormatter(nl)); //add formatter to the list of formatters
        }
        TextEditor te = new TextEditor(f);
        te.printAll();   
    }
}
