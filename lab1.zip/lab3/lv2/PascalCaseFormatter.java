import java.util.*;
import java.lang.StringBuilder;

class PascalCaseFormatter implements TextFormatter {

    String str;
    // create a clone of the TextFormatter with another String
    public TextFormatter clone(String s){ //s is a whole line of words 
        return new PascalCaseFormatter(s);
    }

    public PascalCaseFormatter(String s) {
        this.str = s;
    }

    // return a formatted String
    public String format(){
        String temp = str.toLowerCase();
        char init = Character.toUpperCase(temp.charAt(0));
        StringBuilder sb = new StringBuilder(temp);
        sb.replace(0, 1, "" + init);
        for (int i = 0; i < sb.length(); i++) {
            if (sb.charAt(i) == ' ') {
               char upp = Character.toUpperCase(sb.charAt(i+1));
               sb.replace(i+1, i+2, "" + upp);
               sb.deleteCharAt(i);
            }
        }
        return sb.toString();
    }
}
