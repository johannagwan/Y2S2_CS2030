interface MixedTestFormatter extends TextFormatter {
    public void checkR();
}
