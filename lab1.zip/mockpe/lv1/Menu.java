class Menu {
    public int id;
    public String type;
    public String desc;
    public int price;

    public Menu(int id, String type, String desc, int price) {
        this.id = id;
        this.type = type;
        this.desc = desc;
        this.price = price;
    }

    public String toString() {
        return "#" + id + " " + type + ": " + desc + " (" + price + ")";
    }
}
