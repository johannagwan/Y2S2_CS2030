import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Main {
    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in);
        ArrayList<Menu> menuArr = new ArrayList<Menu>();
        int id = 0;
        while (sc.next().equals("add")) {
            String type = sc.next();
            String desc = sc.next();
            int price = sc.nextInt();
            menuArr.add(new Menu(id, type, desc, price));
            id++;
        }

        for (int i = 0; i < menuArr.size(); i++) {
            System.out.println(menuArr.get(i));
        }
        
    }
}
