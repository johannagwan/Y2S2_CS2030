import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Main {
   
	static ArrayList<Menu> menuArr = new ArrayList<Menu>();
	static ArrayList<Integer> orderArr = new ArrayList<Integer>();
   
	public static void main(String[] args) { 
        
		Scanner sc = new Scanner(System.in);
        
        int id = 0;
        while (sc.next().equals("add")) {
            String type = sc.next();
            if (type.equals("Combo")) {
                ArrayList<Integer> comboArr = new ArrayList<Integer>();
                while (sc.hasNextInt()) {
                    comboArr.add(sc.nextInt());
                }
				menuArr.add(new Combo(id, type, "", 0, comboArr));                      
				id++;
            } else {
                String desc = sc.next();
                int price = sc.nextInt();
                menuArr.add(new Menu(id, type, desc, price));
                id++;
            }
        }
        printMenu();
        readOrder(sc);
        printOrder();
    }

    public static void printMenu() {
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Burger")) {
                System.out.println(menuArr.get(i));
            } 
        }

        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Snack")) {
                System.out.println(menuArr.get(i));
            } 
        }

        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Drink")) {
                System.out.println(menuArr.get(i));
            } 
        }
    }

	
    public static void readOrder(Scanner sc) {
        while (sc.hasNextInt()) {
            orderArr.add(sc.nextInt());
        }
    }
	
	public static void printOrder() {
        System.out.println("--- Order ---");
        int totalPrice = 0;
		int cc = 0;
		int comboCounter = 0;
		for (int i = 0; i < orderArr.size(); i++) {
			for (int j = 0; j < menuArr.size(); j++) {
				if (orderArr.get(i) == menuArr.get(j).getId() &&
					menuArr.get(j).getType().equals("Combo")) {
						comboCounter++;
					}
			}
		}
        
        for (int i = 0; i < orderArr.size(); i++) { // to iterate the order number through the menuArr
			for (int j = 0; j < menuArr.size(); j++) {
				if (orderArr.get(i) == menuArr.get(j).getId()) {
					if (menuArr.get(j) instanceof Combo && cc < comboCounter) {
						Combo c = (Combo) menuArr.get(j);
						int cprice = countComboPrice(c.getComboArray());
						totalPrice += cprice;
						int comboId = c.getId();
						printCombo(comboId, c.getComboArray(), cprice);
						cc++;
						break;
	  
					} else { 
						totalPrice += menuArr.get(j).getPrice(); 
						System.out.println(menuArr.get(j));
					}
				}				
            }
        } 
        System.out.println("Total: " + totalPrice);
    }

    
    public static int countComboPrice(ArrayList<Integer> comboArr) { //calculate comboprice      
        int totalComboPrice = -50;
        for (int i = 0; i < 3; i++) { //to get the totalComboPrice first
            for (int k = 0; k < menuArr.size(); k++) {
                if (comboArr.get(i) == menuArr.get(k).getId()) {
                    totalComboPrice += menuArr.get(k).getPrice();
                    break;
                }
            }
        }
        return totalComboPrice;
    }
        
    
    public static void printCombo(int comboId, ArrayList<Integer> comboArr, int totalComboPrice) {       
        Combo c = new Combo(comboId, "Combo", "", totalComboPrice, comboArr);
        System.out.println(c);                        

        for (int i = 0; i < 3; i++) {
            for (int k = 0; k < menuArr.size(); k++) {
                if (comboArr.get(i) == menuArr.get(k).getId()) {
					System.out.println("   " + menuArr.get(k));  
                }
            }
        }
    }
}
