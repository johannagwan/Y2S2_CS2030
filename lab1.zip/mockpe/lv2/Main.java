import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Main {
    static ArrayList<Menu> menuArr = new ArrayList<Menu>();
    public static void main(String[] args) { 
        Scanner sc = new Scanner(System.in);
        int id = 0;
        while (sc.next().equals("add")) {
            String type = sc.next();
            String desc = sc.next();
            int price = sc.nextInt();
            menuArr.add(new Menu(id, type, desc, price));
            id++;
        }
        printMenu();
    }

    public static void printMenu() {
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Burger")) {
                System.out.println(menuArr.get(i));
            } 
        }
        
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Snack")) {
                System.out.println(menuArr.get(i));
            } 
        }
        
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Drink")) {
                System.out.println(menuArr.get(i));
            } 
        }
    }
}
