import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        int numOfPoints;
        int j = 0;
        Scanner sc = new Scanner(System.in);
        numOfPoints = sc.nextInt();
        int[] counter = new int[numOfPoints * numOfPoints];
        Point[] points = new Point[numOfPoints];
        points[0] = new Point(sc.nextDouble(), sc.nextDouble());
        for (int i = 1; i < numOfPoints; i++) {
            points[i] = new Point(sc.nextDouble(), sc.nextDouble());
        }
       

        int[] pos = new int[numOfPoints * numOfPoints];
        for (int m = 0; m < numOfPoints; m++) { //to compare all possible pts
            for (int n = 0; n < numOfPoints; n++) {
                Point prev = points[m];
                Point curr = points[n];
                Point centre = prev.centreWith(curr); 
                Circle currCircle = new Circle(centre);
                if (prev.lengthWith(curr) <= 2) {
                    counter[j] = currCircle.discCover(points);
                    j++;
                } else {
                    continue;
                }    
            }
        }


        int max = counter[0];
        for (int k = 1; k < j; k++) { //to find max disc coverage, compare each element in the array
            if (counter[k] > max) {
                max = counter[k];
            } else {
                //continue
            }
        }
        System.out.println("Maximum Disc Coverage: " + max);
    }
}
