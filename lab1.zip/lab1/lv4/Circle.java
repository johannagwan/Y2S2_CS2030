class Circle {
    Point centre;
    private double radius = 1;
    private int numOfPoints = 0;

    public Circle(Point centre) {
        this.centre = centre;
    }

    public boolean contains(Point anotherPoint) {
        return this.centre.lengthWith(anotherPoint) <= this.radius;
    }

    public int discCover (Point[] points) {
        for (Point p: points) {
            if (this.contains(p)) {
                numOfPoints++;
            }
        }
        return numOfPoints;
    }
}
