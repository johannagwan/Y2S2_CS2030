import java.util.Scanner;
import java.lang.Math;

class Point {
    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public void setX(double x) {
        this.x = x;
    }
    
    public void setY(double y) {
        this.y = y;
    }
    
    public Point midpoint(Point p, Point q) {
        double x = (p.getX() + q.getX()) / 2;
        double y = (p.getY() + q.getY()) / 2;
        Point mid = new Point(x, y);
        return mid;
    }

    public double angleTo(Point p, Point q) {
        return Math.atan2((q.getY() - p.getY()) , (q.getX() - p.getX()));
    }

    public String getDetails(Point q, Point p) {
        Point centre = Circle.centre(p, q);
        return String.format("(%.3f, %.3f) and (%.3f, %.3f) coincides with circle of centre (%.3f, %.3f)", p.getX(), p.getY(), q.getX(), q.getY(), centre.getX(), centre.getY()); 
    }
}
