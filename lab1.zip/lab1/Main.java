import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        int numOfPoints;
        Scanner sc = new Scanner(System.in);
        numOfPoints = sc.nextInt();
        Point[] points = new Point[numOfPoints];
        points[0] = new Point(sc.nextDouble(), sc.nextDouble());
        for (int i = 1; i < numOfPoints; i++) {
            points[i] = new Point(sc.nextDouble(), sc.nextDouble());
        }
        
        for (int j = 1; j < numOfPoints; j++) {
            Circle circle = new Circle(points[j], points[j - 1]);
            if (circle.isCircle) {
               System.out.println(Circle.getDetails(points[j], points[j - 1]));           
            } else {
                // do nothing
            }
        }
    }
}
