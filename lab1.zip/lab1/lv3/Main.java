import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        int numOfPoints;
        Scanner sc = new Scanner(System.in);
        numOfPoints = sc.nextInt();
        Point[] points = new Point[numOfPoints];
        points[0] = new Point(sc.nextDouble(), sc.nextDouble());
        for (int i = 1; i < numOfPoints; i++) {
            Point prev = points[i - 1];
            points[i] = new Point(sc.nextDouble(), sc.nextDouble());
            Point curr = points[i];

            if (prev.lengthWith(curr) <= 2) {
                System.out.println(prev.getDetails(curr));
            } else {
                continue;
            }    
        }
    }
}
