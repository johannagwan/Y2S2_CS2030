class Circle {
    Point centre;

    public Circle(Point centre) {
        this.centre = centre;
    }

}
