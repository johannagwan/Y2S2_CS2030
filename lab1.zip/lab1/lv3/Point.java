import java.util.Scanner;
import java.lang.Math;

class Point {
    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public void setX(double x) {
        this.x = x;
    }
    
    public void setY(double y) {
        this.y = y;
    }
    
    public Point midpoint(Point q) {
        double x = (this.getX() + q.getX()) / 2;
        double y = (this.getY() + q.getY()) / 2;
        Point mid = new Point(x, y);
        return mid;
    }

    public double angleTo(Point q) {
        return Math.atan2((q.getY() - this.getY()) , (q.getX() - this.getX()));
    }

    public double lengthWith(Point q) {
        double distX = this.getX() - q.getX();
        double distY = this.getY() - q.getY();
        return Math.sqrt(distX * distX + distY * distY);
    }


    public Point centreWith(Point q) {
        double pm = this.lengthWith(q) / 2;
        double dist = Math.sqrt(1 - pm * pm);        
        double angle = this.angleTo(q) + Math.PI / 2;
        double x = this.midpoint(q).getX() + dist * Math.cos(angle);
        double y = this.midpoint(q).getY() + dist * Math.sin(angle);
        
        Point centre = new Point(x, y);
        return centre;
    }

    public String getDetails(Point q) {
        Point mid = this.midpoint(q);
        Circle c = new Circle(this.centreWith(q));
        return String.format("(%.3f, %.3f) and (%.3f, %.3f) coincides with circle of centre (%.3f, %.3f)", this.getX(), this.getY(), q.getX(), q.getY(), c.centre.getX(), c.centre.getY());
    }
}
