import java.lang.Math;

class Circle {
    Point point1;
    Point point2;
    double radius;   
    boolean isCircle = false;
    Point centre;
    public Circle(Point p, Point q) {
        point1 = p;
        point2 = q;
        radius = 1;
        Centre(point1, point2);
    
    
    public double distanceTwoPoints(Point p, Point q) {
        double distX = p.getX() - q.getX();
        double distY = p.getY() - q.getY();
        return Math.sqrt(distX * distX + distY * distY);
    }
   
    public double distance(Point m, Point q) {
        double distM = distanceTwoPoints(m, q);
        if (distM < radius ) {
            isCircle = true;
            return Math.sqrt(radius - distM * distM);
        } else {
            return Double.NaN;  
        }
    }

    public Point midpoint(Point p, Point q) {
        double x = (p.getX() + q.getX()) / 2;
        double y = (p.getY() + q.getY()) / 2;
        Point mid = new Point(x, y);
        return mid;
    }
    public void Centre(Point p, Point q) {
        
        Point mid = midpoint(p, q);
        double angle = Point.angleTo(p, q);
        double x = mid.getX() - distance(mid, q) * Math.sin(angle);
        double y = mid.getY() + distance(mid, q) * Math.cos(angle);

        centre = new Point(x, y);
    }

    static public String getDetails(Point q, Point p) {
        return String.format("(%.3f, %.3f) and (%.3f, %.3f) coincides with circle of centre (%.3f, %.3f)", p.getX(), p.getY(), q.getX(), q.getY(), centre.getX(), centre.getY());
        }
}
