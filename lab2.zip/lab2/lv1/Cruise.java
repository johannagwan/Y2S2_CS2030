class Cruise{
    private String code;
    private int time;
    
    public Cruise(String code, int time) {
        this.code = code;
        this.time = time;
    }
    
    @Override
    public String toString() {
        return code + "@" + String.format("%04d", time);
    }
}
