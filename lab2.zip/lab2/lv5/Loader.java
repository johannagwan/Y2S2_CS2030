import java.util.ArrayList;
import java.util.List;

class Loader{

    ArrayList<Cruise> cruise = new ArrayList<Cruise>();    
    protected int numLoader;
    protected int prevCruiseTime = 0;
    protected static int totalLoader = 0;

    public Loader(int numLoader) {
        this.numLoader = numLoader;
        totalLoader++;
    }

    public int nextLoadTime(Cruise c) {
        prevCruiseTime = c.getTime() + c.workTime();
        return prevCruiseTime;
    }

    public boolean checkAvail(Cruise c) {
        return (prevCruiseTime <= c.getTime());

    }

    public void getServe(Cruise c) { //arraylist of cruises the loader serve
        cruise.add(c);
        nextLoadTime(c);
    }


    public static int getTotalLoader() {
        return totalLoader;
    }

    public void PrintCruise() {
        Main.Sentence("Loader " + (numLoader + 1) + " serves:");
        for (int i = 0; i < cruise.size(); i++) {
            Main.Sentence("    " + cruise.get(i).toString());
        }
    }
}
