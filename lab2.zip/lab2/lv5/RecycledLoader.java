class RecycledLoader extends Loader {
    public static int totalRecycledLoader = 0;
        
    public RecycledLoader(int numLoader) {
        super(numLoader);
        totalRecycledLoader++;
        super.totalLoader--;
    }


    public int nextLoadTime(Cruise c) {
        prevCruiseTime = c.getTime() + c.workTime() + 60;
        return prevCruiseTime;
    }

    public static int getTotalLoader() {
        return totalRecycledLoader;
    }

    public void PrintCruise() {
        Main.Sentence("Loader " + (numLoader + 1) + " (recycled) serves:");
        for (int i = 0; i < cruise.size(); i++) {
            Main.Sentence("    " + cruise.get(i).toString());
        }
    }
}
