class RecycledLoader extends Loader {
    public RecycledLoader(int numLoader) {
        super(numLoader);
    }

    public int nextLoadTime(Cruise c) {
        prevCruiseTime = c.getTime() + c.workTime() + 60;
        return prevCruiseTime;
    }

    public void PrintCruise() {
        System.out.println("Loader " + (numLoader + 1) + " (recycled) serves:");
        for (int i = 0; i < cruise.size(); i++) {
            System.out.println("    " + cruise.get(i).toString());
        }
    }
}
