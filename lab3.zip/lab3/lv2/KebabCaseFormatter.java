import java.util.*;
import java.lang.StringBuilder;

class KebabCaseFormatter implements TextFormatter{
    String str;
    public TextFormatter clone(String s) {
        return new KebabCaseFormatter(s);
    }

    public KebabCaseFormatter(String s) {
        this.str = s;
    }

    public String format() {
        String temp = str.toLowerCase();
        StringBuilder sb = new StringBuilder(temp);
        for (int i = 0; i < sb.length(); i++) {
            if (temp.charAt(i) == ' ') {
                sb.replace(i, i+1, "-");
            }
        }
        return sb.toString();
    }
}
