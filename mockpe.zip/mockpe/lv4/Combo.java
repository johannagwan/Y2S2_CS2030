import java.util.ArrayList;
import java.util.List;

class Combo extends Menu {	
	ArrayList<Integer> comboArr;
	
	public Combo(int id, String type, String desc, int price, ArrayList<Integer> comboArr) {
        super(id, type, desc, price);
		this.comboArr = comboArr;
		
    }

	public ArrayList<Integer> getComboArray() {
		return comboArr;
	}
	
    public String toString() {
        return "#" + id + " Combo (" + price + ")";
    }
}
