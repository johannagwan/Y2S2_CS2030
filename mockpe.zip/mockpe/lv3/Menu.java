class Menu {
    public int id;
    public String type;
    public String desc;
    public int price;

    public Menu(int id, String type, String desc, int price) {
        this.id = id;
        this.type = type;
        this.desc = desc;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public int getPrice() {
        return price;
    }

    public String toString() {
        return "#" + id + " " + type + ": " + desc + " (" + price + ")";
    }
}
