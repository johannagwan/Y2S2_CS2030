import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

class Main {
    static ArrayList<Menu> menuArr = new ArrayList<Menu>();
    static ArrayList<Integer> orderArr = new ArrayList<Integer>();
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) { 
        int id = 0;
        while (sc.next().equals("add")) {
            String type = sc.next();
            String desc = sc.next();
            int price = sc.nextInt();
            menuArr.add(new Menu(id, type, desc, price));
            id++;
        }
        printMenu();
        readOrder();
        printOrder();
    }

    public static void printMenu() {
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Burger")) {
                System.out.println(menuArr.get(i));
            } 
        }
        
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Snack")) {
                System.out.println(menuArr.get(i));
            } 
        }
        
        for (int i = 0; i < menuArr.size(); i++) {
            if (menuArr.get(i).getType().equals("Drink")) {
                System.out.println(menuArr.get(i));
            } 
        }
    }

    public static void readOrder() {
        while (sc.hasNextInt()) {
            orderArr.add(sc.nextInt());
        }
    }

    public static void printOrder() {
       System.out.println("--- Order ---");
       int totalPrice = 0;
       for (int i = 0; i < orderArr.size(); i++) {
            for (int j = 0; j < menuArr.size(); j++) {
                if (orderArr.get(i) == menuArr.get(j).getId()) {
                    totalPrice += menuArr.get(j).getPrice(); 
                    System.out.println(menuArr.get(j));
                }
            }
       } 
       System.out.println("Total: " + totalPrice);
    }
}
